Stale Pixels User Interface tools (aka SPUI)
--

Abstract
==
SPUI is a DotCommand for the ZX Spectrum Next. It's primary (sole?) purpose is 
to make the creation of User Interaction flows from NextBASIC 
    (a) more convenient; 
    (b) less ugly; 
    (c) more consistent;
    (d) less effort!

Quick Start
==
.SPUI -h  will get you the built-in help.

When building GUIs the parameter <TYPE> is compulsory. 

Setup
==
 To prevent unexpected side effects, unless instructed, you should preload Register 0x7F with 0.
 
More Information
==
See the /docs/ folder

--Xalior, 20200626
